package com.example.pensee

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.pensee.app.MyApplication

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val buttonBack = findViewById<ImageView>(R.id.back_button)

        buttonBack.setOnClickListener {
            finish()
        }

        val buttonLogout = findViewById<TextView>(R.id.logout_button)
        buttonLogout.setOnClickListener {

            val builder =  AlertDialog.Builder(this)
            builder.setMessage("Are you sure you want to logout?")
            builder.setPositiveButton("Yes") { _, _ ->
                startActivity(Intent(this, LoginActivity::class.java))
                MyApplication.setEmail("")
                finish()
            }

            builder.setNegativeButton("No") {_, _ ->
            }

            builder.show()
        }

        val buttonAccount = findViewById<TextView>(R.id.account_button)
        buttonAccount.setOnClickListener {
            startActivity(Intent(this, ComingFeatureActivity::class.java))
        }

        val buttonPremium = findViewById<TextView>(R.id.gopremium_button)
        buttonPremium.setOnClickListener {
            startActivity(Intent(this, ComingFeatureActivity::class.java))
        }

        val buttonThemes = findViewById<TextView>(R.id.theme_button)
        buttonThemes.setOnClickListener {
            startActivity(Intent(this, ComingFeatureActivity::class.java))
        }

        val buttonCustomApp = findViewById<TextView>(R.id.customicon_button)
        buttonCustomApp.setOnClickListener {
            startActivity(Intent(this, ComingFeatureActivity::class.java))
        }

        val buttonMediumConnect = findViewById<TextView>(R.id.connectmedium_button)
        buttonMediumConnect.setOnClickListener {
            startActivity(Intent(this, ComingFeatureActivity::class.java))
        }

        val buttonFacebookConnect = findViewById<TextView>(R.id.connectfb_button)
        buttonFacebookConnect.setOnClickListener {
            startActivity(Intent(this, ComingFeatureActivity::class.java))
        }

        val buttonAboutUs = findViewById<TextView>(R.id.about_us)
        buttonAboutUs.setOnClickListener {
            startActivity(Intent(this, AboutUsActivity::class.java))
        }

        val buttonDevelopers = findViewById<TextView>(R.id.developers_button)
        buttonDevelopers.setOnClickListener {
            startActivity(Intent(this, DevelopersActivity::class.java))
        }

    }
}