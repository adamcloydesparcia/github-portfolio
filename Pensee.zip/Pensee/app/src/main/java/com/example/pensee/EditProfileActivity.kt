package com.example.pensee

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.Image
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.pensee.app.MyApplication
import com.example.pensee.utils.isNotValid
import com.example.pensee.utils.toast
import org.w3c.dom.Text

class EditProfileActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)

        val chooseImage = findViewById<TextView>(R.id.choose_image)
        chooseImage.setOnClickListener {
            startActivity(Intent(this, ComingFeatureActivity::class.java))
        }

        val textName = findViewById<EditText>(R.id.name_text)

        textName.setText(MyApplication.name())

        val buttonBack = findViewById<ImageView>(R.id.back_button)

        buttonBack.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java).putExtra("fragment", "profile"))
            finish()
        }

        val buttonSave = findViewById<TextView>(R.id.save_button)
        buttonSave.setOnClickListener {
            if (textName.isNotValid()) {
                toast("Field name shouldn't be empty!")
                return@setOnClickListener
            }

            MyApplication.updateProfile(textName.text.toString())
            startActivity(Intent(this, MainActivity::class.java).putExtra("fragment", "profile"))
            finish()
        }

        val border = GradientDrawable()
        border.setColor(Color.parseColor("#F9F9F9"))
        border.setStroke(1, Color.parseColor("#009988"))
        border.cornerRadius = 20f
        textName.background = border

    }
}