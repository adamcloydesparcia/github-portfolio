package com.example.pensee

import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.example.pensee.app.MyApplication
import com.example.pensee.utils.saveUserList

class MainActivity : AppCompatActivity() {


    override fun onStop() {
        super.onStop()
        saveUserList(MyApplication.getUserList())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val home = findViewById<ImageView>(R.id.home)
        val search = findViewById<ImageView>(R.id.search)
        val saved = findViewById<ImageView>(R.id.saved)
        val user = findViewById<ImageView>(R.id.usr)


        if (intent?.getStringExtra("fragment") == "profile") {
            supportFragmentManager.beginTransaction().replace(R.id.main_fragment, ProfileFragment()).commit()
            user.setImageResource(R.drawable.user_logo)
            home.setImageResource(R.drawable.home_unclicked)
            saved.setImageResource(R.drawable.saved_unclicked)
            search.setImageResource(R.drawable.search_unclicked)
        }
        else {
            supportFragmentManager.beginTransaction().add(R.id.main_fragment, HomeFragment()).commit()
            home.setImageResource(R.drawable.home)
            saved.setImageResource(R.drawable.saved_unclicked)
            user.setImageResource(R.drawable.user_logo_unclicked)
            search.setImageResource(R.drawable.search_unclicked)
        }


        home.setOnClickListener {
            supportFragmentManager.beginTransaction().replace(R.id.main_fragment, HomeFragment()).commit()
            home.setImageResource(R.drawable.home)
            saved.setImageResource(R.drawable.saved_unclicked)
            user.setImageResource(R.drawable.user_logo_unclicked)
            search.setImageResource(R.drawable.search_unclicked)
        }

        search.setOnClickListener {
            supportFragmentManager.beginTransaction().replace(R.id.main_fragment, SearchFragment()).commit()
            home.setImageResource(R.drawable.home_unclicked)
            search.setImageResource(R.drawable.search)
            saved.setImageResource(R.drawable.saved_unclicked)
            user.setImageResource(R.drawable.user_logo_unclicked)
        }

        saved.setOnClickListener {
            supportFragmentManager.beginTransaction().replace(R.id.main_fragment, LibraryFragment()).commit()
            saved.setImageResource(R.drawable.saved)
            home.setImageResource(R.drawable.home_unclicked)
            user.setImageResource(R.drawable.user_logo_unclicked)
            search.setImageResource(R.drawable.search_unclicked)
        }

        user.setOnClickListener {
            supportFragmentManager.beginTransaction().replace(R.id.main_fragment, ProfileFragment()).commit()
            user.setImageResource(R.drawable.user_logo)
            home.setImageResource(R.drawable.home_unclicked)
            saved.setImageResource(R.drawable.saved_unclicked)
            search.setImageResource(R.drawable.search_unclicked)
        }
    }
}