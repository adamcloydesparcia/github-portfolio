package com.example.pensee

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.pensee.app.MyApplication
import com.example.pensee.utils.PublicCustomListAdapter

class ForYouFragment : Fragment() {

    private lateinit var adapter: PublicCustomListAdapter
    private lateinit var listView: ListView

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val following = view.findViewById<TextView>(R.id.following)
        following.setOnClickListener {
            (context as AppCompatActivity).supportFragmentManager.beginTransaction().replace(R.id.public_fragment, FollowingFragment()).commit()
        }


        listView = view.findViewById(R.id.list_view)
        adapter = PublicCustomListAdapter(requireContext(), MyApplication.getPublicList())
        listView.adapter = adapter
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_for_you, container, false)
    }




}