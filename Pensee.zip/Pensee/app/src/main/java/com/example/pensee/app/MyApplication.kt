package com.example.pensee.app

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context
import android.util.Log
import androidx.appcompat.app.AppCompatDelegate
import com.example.pensee.R
import java.time.LocalDate.now

data class SharedList(
    var title: String,
    var body: String
)

data class SavedLists(
    var user: String,
    var title: String,
    var body: String
)

data class MutableTriple(
    var first: String,
    var second: String,
    var third: String
)

data class MutablePair(
    var title: String,
    var body: StringBuilder
)


class MyApplication : Application() {


    override fun onCreate() {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        super.onCreate()
        instance = this
        Log.e("Checker", "This line should be called!")
        setPublicList()
    }


    companion object {

        private var userList = ArrayList<Pair<ArrayList<MutablePair>, MutableTriple>>()

        private var email = ""
        private var file  = ""

        fun setUserList(userList: ArrayList<Pair<ArrayList<MutablePair>, MutableTriple>>) {
            this.userList = userList
        }

        fun getUserList() : ArrayList<Pair<ArrayList<MutablePair>, MutableTriple>> {
            return userList
        }

        fun clearUserList() {
            userList.clear()
        }

        fun setEmail(email: String) {
            this.email = email
        }

        fun getEmail() : String = email


        fun setTitle(file: String) {
            this.file = file
        }

        fun getTitle() : String = file


        fun getCorrespondingList() : ArrayList<MutablePair>? {
            return userList.find { (_, userData) -> userData.second == email }?.first
        }

        fun deleteCorrespondingList(title: String) {
            deleteFromSharedList(title)
            val index = userList.indexOfFirst { (filesData, _) -> filesData.any { pair -> pair.title == title } }
            if (index != -1)
                userList.first().first.removeAt(index)
        }

        fun addUser(username: String, email: String, password: String) {

            val emptyList = ArrayList<MutablePair>()
            val triples = MutableTriple(username, email, password)
            val newUser = Pair(emptyList, triples)
            userList.add(newUser)
        }

        fun contain(email: String, password: String) : Boolean {
            return userList.any { (_, userData) -> userData.second == email && userData.third == password }
        }

        fun emailExists(email: String) : Boolean {
            return userList.any { (_, userData) -> userData.second == email }
        }

        fun name() : String? {
            return userList.find { (_, userData) -> userData.second == email }?.second?.first
        }

        fun addFile(body: String) {
            userList.find { (_, userData) -> userData.second == email }?.first?.add(MutablePair(file, StringBuilder(body)))
        }

        fun updateProfile(name: String) {
            userList.find { (_, userData) -> userData.second == email }?.second?.first = name
        }

        fun updateFile(title: String, body: StringBuilder) {
            userList.find { (_, userData) -> userData.second == email }?.first?.find { pair -> pair.title == file }?.title = title
            userList.find { (_, userData) -> userData.second == email }?.first?.find { pair -> pair.title == file }?.body = body
        }

        fun getFile() : MutablePair? {
            return userList.find { (_, userData) -> userData.second == email }?.first?.find { pair ->
                pair.title == file
            }
        }

        fun fileExists(title: String) : Boolean? {
            return userList.find { (_, userData) -> userData.second == email }?.first?.any { pair -> pair.title == title }
        }

        // Journal contents
        private lateinit var instance: MyApplication

        fun getStringResource(id: Int): String {
            return instance.getString(id)
        }

        val journals: List<String>
            get() = listOf(
                getStringResource(R.string.journal1),
                getStringResource(R.string.journal2),
                getStringResource(R.string.journal3),
                getStringResource(R.string.journal4),
                getStringResource(R.string.journal5),
                getStringResource(R.string.journal6),
                getStringResource(R.string.journal7),
                getStringResource(R.string.journal8),
                getStringResource(R.string.journal9),
                getStringResource(R.string.journal10)

            )


        // Public shared journals list
        private val publicList = ArrayList<Triple<String, String?, MutablePair>>()

        fun setPublicList() {
            publicList.add(Triple("2025-04-21", "Emily J.", MutablePair("Morning Musings", StringBuilder(journals[0]))))
            publicList.add(Triple("2025-04-21", "David K.", MutablePair("Lost in Thought", StringBuilder(journals[1]))))
            publicList.add(Triple("2025-04-21", "Sophia L.", MutablePair("Coffee Break", StringBuilder(journals[2]))))
            publicList.add(Triple("2025-04-21", "Rachel T.", MutablePair("Life's Lessons", StringBuilder(journals[3]))))
            publicList.add(Triple("2025-04-21", "Ethan W.", MutablePair("Nature's Symphony", StringBuilder(journals[4]))))
            publicList.add(Triple("2025-04-21", "Ava G.", MutablePair("Gratitude", StringBuilder(journals[5]))))
            publicList.add(Triple("2025-04-21", "Liam N.", MutablePair("Dreams and Aspirations", StringBuilder(journals[6]))))
            publicList.add(Triple("2025-04-21", "Mia K.", MutablePair("Self Discovery", StringBuilder(journals[7]))))
            publicList.add(Triple("2025-04-21", "Jackson H.", MutablePair("Smile Often", StringBuilder(journals[8]))))
            publicList.add(Triple("2025-04-21", "Olivia P.", MutablePair("Moonlight Reflections", StringBuilder(journals[9]))))
        }

        fun deleteFromPublicList(title: String) {
            if (publicList.any { it.second == name()}) {
                val index = publicList.indexOfFirst { list -> list.third.title == title }

                if (index != -1) {
                    publicList.removeAt(index)
                    deleteFromPublicList(title)
                }
            }
        }

        fun getPublicList() : ArrayList<Triple<String, String?, MutablePair>> = publicList

        @SuppressLint("NewApi")
        fun shareToPublic(body: StringBuilder) {
            val date = now().toString()

            val user = name()
            val pair = MutablePair(file, body)
            val newList = Triple(date, user, pair)

            if (!(publicList.any { it.third.title == file }))
                publicList.add(0, newList)
        }

        private var name = ""
        private var content = StringBuilder()

        fun setName(name: String) {
            this.name = name
        }

        fun getName() : String = name

        fun setContent(content: StringBuilder) {
            this.content = content
        }

        fun getContent() : StringBuilder = content



        // Saved Lists
        private var savedLists = ArrayList<SavedLists>()

        fun setSavedLists(savedLists: ArrayList<SavedLists>) {
            this.savedLists = savedLists
        }

        fun getSavedLists() : ArrayList<SavedLists> = savedLists

        @SuppressLint("NewApi")
        fun addLikedList(list: SavedLists) {
            if (!(savedLists.any { it.title == list.title }))
                savedLists.add(0, list)
        }

        fun deleteLikedList(title: String) {
            val index = savedLists.indexOfFirst { list -> list.title == title }

            if (index != -1) {
                savedLists.removeAt(index)
            }

        }

        // Following Lists
        private var followingList = ArrayList<SavedLists>()

        fun setFollowingList(followingList: ArrayList<SavedLists>) {
            this.followingList = followingList
        }

        fun getFollowingList() : ArrayList<SavedLists> = followingList

        @SuppressLint("NewApi")
        fun addFollowingList(list: SavedLists) {
            if (!(followingList.any { it.user == list.user }))
                followingList.add(0, list)
        }

        fun deleteFollowingList(user: String) {
            val index = followingList.indexOfFirst { list -> list.user == user }

            if (index != -1) {
                followingList.removeAt(index)
                deleteFollowingList(user)
            }
        }


        private var resultsList = ArrayList<Triple<String, String?, MutablePair>>()

        fun setResultList(resultList: ArrayList<Triple<String, String?, MutablePair>>) {
            this.resultsList = resultList
        }

        fun getResultList() : ArrayList<Triple<String, String?, MutablePair>> = resultsList

        @SuppressLint("NewApi")
        fun addResultToList(list: Triple<String, String?, MutablePair>) {
            resultsList.add(0, list)
        }

        fun clearList() {
            resultsList.clear()
        }


        private var searchList = ArrayList<String>()

        fun setSearchList(searchList: ArrayList<String>) {
            this.searchList = searchList
        }

        fun getSearchList() : ArrayList<String> = searchList

        @SuppressLint("NewApi")
        fun addSearchList(query: String) {
            if (!(searchList.any { it == query }))
                searchList.add(0, query)
        }

        fun removeFromSearchList(query: String) {
            val index = searchList.indexOfFirst { it == query }

            if (index != -1) {
                searchList.removeAt(index)
            }
        }

        private var sharedList = ArrayList<SharedList>()

        fun setSharedList(sharedList: ArrayList<SharedList>) {
            this.sharedList = sharedList
        }

        fun getSharedList() : ArrayList<SharedList> = sharedList

        fun addToSharedList(list: SharedList) {
            if (!(sharedList.any { it.title == list.title }))
                sharedList.add(0, list)
        }

        fun deleteFromSharedList(title: String) {
            val index = sharedList.indexOfFirst { it.title == title }

            if (index != -1) {
                deleteFromPublicList(title)
                sharedList.removeAt(index)
            }
        }

    }

}