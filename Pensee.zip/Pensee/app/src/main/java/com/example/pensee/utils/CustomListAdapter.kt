package com.example.pensee.utils

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.PopupWindow
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.FragmentManager
import com.example.pensee.HomeFragment
import com.example.pensee.MainActivity
import com.example.pensee.ProfileFragment
import com.example.pensee.R
import com.example.pensee.ViewFileActivity
import com.example.pensee.app.MutablePair
import com.example.pensee.app.MyApplication
import com.example.pensee.app.SharedList

class CustomListAdapter(
    private val context: Context,
    private val list: ArrayList<MutablePair>?
    ) : BaseAdapter() {

    private lateinit var popupWindow: PopupWindow
    private var popupIsClicked = false


    @SuppressLint("SetTextI18n")
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {

        val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.profile_files_list, parent, false)


        val title = list?.get(position)?.title
        val body = list?.get(position)?.body

        val textViewTitle = view.findViewById<TextView>(R.id.textview_title)
        val textViewBody = view.findViewById<TextView>(R.id.textview_body)
        val imageViewOption = view.findViewById<ImageView>(R.id.imageView_option)

        textViewTitle.text = title
        val bodyFiltered = body?.split("\n")
        if (body?.length?.compareTo(50) == 1) {
            textViewBody.text = bodyFiltered?.joinToString(" ")?.substring(0, 50) + "..."
        }
        else {
            textViewBody.text = bodyFiltered?.joinToString(" ")?.substring(0, body.length)
        }

        imageViewOption.setOnClickListener {
            val context = parent?.context
            if (context != null) {
                if (popupIsClicked) {
                    popupWindow.dismiss()
                    popupIsClicked = false
                }
                else {
                    val inflater = LayoutInflater.from(context)
                    val popUpView = inflater.inflate(R.layout.popup_layout, parent, false)

                    val border = GradientDrawable()
                    border.setColor(Color.parseColor("#F9F9F9"))
                    border.setStroke(1, Color.parseColor("#009988"))

                    val popupShare = popUpView.findViewById<TextView>(R.id.share)
                    popupShare.text = "Share"

                    val popupDelete = popUpView.findViewById<TextView>(R.id.delete)
                    popupDelete.text = "Delete"

                    val popupShareIcon = popUpView.findViewById<ImageView>(R.id.share_icon)
                    popupShareIcon.setImageResource(R.drawable.share)

                    val popupDeleteIcon = popUpView.findViewById<ImageView>(R.id.delete_icon)
                    popupDeleteIcon.setImageResource(R.drawable.delete)

                    val popupShareField = popUpView.findViewById<RelativeLayout>(R.id.share_field)
                    popupShareField.background = border
                    popupShareField.setOnClickListener {

                        val builder = android.app.AlertDialog.Builder(parent.context)
                        builder.setMessage("You're about to share this journal to public.")
                        builder.setPositiveButton("Share") { _, _ ->
                            MyApplication.setTitle(textViewTitle.text.toString())
                            MyApplication.addToSharedList(SharedList(textViewTitle.text.toString(), body.toString()))
                            MyApplication.shareToPublic(StringBuilder(body.toString()))
                            context.startActivity(Intent(context, MainActivity::class.java))
                            popupWindow.dismiss()
                        }
                        builder.setNegativeButton("Cancel") { _, _ ->
                        }

                        builder.show()
                    }

                    val popupDeleteField = popUpView.findViewById<RelativeLayout>(R.id.delete_field)
                    popupDeleteField.background = border
                    popupDeleteField.setOnClickListener {


                        val builder = android.app.AlertDialog.Builder(parent.context)
                        builder.setMessage("Are you sure you want to delete this file?")
                        builder.setPositiveButton("Delete") { _, _ ->
                            MyApplication.setTitle(textViewTitle.text.toString())
                            MyApplication.deleteCorrespondingList(MyApplication.getTitle())
                            (context as AppCompatActivity).supportFragmentManager.beginTransaction().replace(R.id.main_fragment, ProfileFragment()).commit()
                            popupWindow.dismiss()
                        }
                        builder.setNegativeButton("Cancel") { _, _ ->
                        }

                        builder.show()
                    }

                    popupWindow = PopupWindow(
                        popUpView,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                    popupWindow.showAsDropDown(imageViewOption, -270, -50)
                    popupIsClicked = true
                }
            }
        }


        view.setOnClickListener {
            MyApplication.setTitle(textViewTitle.getText().toString())
            context.startActivity(Intent(context, ViewFileActivity::class.java).putExtra("private_file", "private_file"))
        }

        return view
    }

    override fun getCount(): Int = list?.size!!

    override fun getItem(position: Int): Any = list!![position]

    override fun getItemId(position: Int): Long = position.toLong()


}