package com.example.pensee

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.pensee.app.MyApplication
import com.example.pensee.utils.toast

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)


        val email = findViewById<EditText>(R.id.email_input)
        val password = findViewById<EditText>(R.id.password_input)

        val buttonRegister = findViewById<TextView>(R.id.button_register)
        val buttonLogin = findViewById<Button>(R.id.button_login)



        buttonLogin.setOnClickListener {
            MyApplication.setEmail(email.text.toString())

            if (MyApplication.contain(email.text.toString(), password.text.toString())){
                startActivity(
                    Intent(this, QuotesActivity::class.java))
                finish()
            }
            else {
                toast("username or password is incorrect!")
                return@setOnClickListener
            }


        }

        buttonRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }

    }

}