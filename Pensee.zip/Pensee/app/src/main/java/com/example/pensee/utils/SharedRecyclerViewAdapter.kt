package com.example.pensee.utils

import android.content.Context
import android.content.Intent
import android.media.Image
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.example.pensee.FollowingFragment
import com.example.pensee.LibraryFragment
import com.example.pensee.R
import com.example.pensee.SharedFragment
import com.example.pensee.ViewFileActivity
import com.example.pensee.app.MyApplication
import com.example.pensee.app.SavedLists
import com.example.pensee.app.SharedList
import org.w3c.dom.Text

class SharedRecyclerViewAdapter(private val context: Context, private val list: ArrayList<SharedList>) : RecyclerView.Adapter<SharedRecyclerViewAdapter.ItemViewHolder>() {
    class ItemViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title = view.findViewById<TextView>(R.id.textview_title)
        val body = view.findViewById<TextView>(R.id.textview_body)
        val imageViewOption = view.findViewById<ImageView>(R.id.imageView_option)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ItemViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.profile_files_list, parent, false)
        return ItemViewHolder(view)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val title = list[position].title
        val body = list[position].body

        holder.title.text = title
        if (body.length >= 80)
            holder.body.text = body.substring(0, 80) + "..."
        else holder.body.text = body
        holder.imageViewOption.setImageResource(R.drawable.delete)
        holder.imageViewOption.setOnClickListener {
            MyApplication.deleteFromSharedList(list[position].title)
            (context as AppCompatActivity).supportFragmentManager.beginTransaction().replace(R.id.list_fragment, SharedFragment()).commit()
        }

        holder.itemView.setOnClickListener {
            MyApplication.setTitle(title)
            MyApplication.setContent(StringBuilder(body))
            context.startActivity(Intent(context, ViewFileActivity::class.java))
        }
    }

    override fun getItemCount(): Int = list.size
}