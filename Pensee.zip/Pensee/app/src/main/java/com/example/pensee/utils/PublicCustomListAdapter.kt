package com.example.pensee.utils

import android.content.Context
import android.content.Intent
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.example.pensee.R
import com.example.pensee.ViewFileActivity
import com.example.pensee.app.MutablePair
import com.example.pensee.app.MyApplication
import com.example.pensee.app.SavedLists
import java.time.LocalDate
import java.time.LocalDate.now
import kotlin.math.absoluteValue

class PublicCustomListAdapter(
    private val context: Context,
    private val list: ArrayList<Triple<String, String?, MutablePair>>
) : BaseAdapter() {


    @RequiresApi(Build.VERSION_CODES.O)
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.public_journal_list, parent, false)

        val date = list[position].first
        val user = list[position].second
        val title = list[position].third.title
        val body = list[position].third.body

        val textViewDate = view.findViewById<TextView>(R.id.date_Created)
        val textViewUser = view.findViewById<TextView>(R.id.textView_user)
        val textViewTitle = view.findViewById<TextView>(R.id.textview_title)
        val textViewBody = view.findViewById<TextView>(R.id.textview_body)


        textViewDate.text = now().until(LocalDate.parse(date)).days.absoluteValue.toString() + "d"
        textViewUser.text = user
        textViewTitle.text = title
        if (body.toString().length >= 80)
            textViewBody.text = body.substring(0, 80) + "..."
        else textViewBody.text = body.toString()

        val imageViewLike = view.findViewById<ImageView>(R.id.heart)

        var likeClicked = MyApplication.getSavedLists().any { it.title == title}

        if (likeClicked) {
            imageViewLike.setImageResource(R.drawable.heart_clicked)
        }

        imageViewLike.setOnClickListener {
            if (!likeClicked) {
                imageViewLike.setImageResource(R.drawable.heart_clicked)
                MyApplication.addLikedList(SavedLists(user.toString(), title, body.toString()))
                likeClicked = true
            }
            else {
                MyApplication.deleteLikedList(title)
                imageViewLike.setImageResource(R.drawable.heart)
                likeClicked = false
            }
        }


        val buttonFollow = view.findViewById<Button>(R.id.follow_button)

        if (MyApplication.name() == user.toString()) {
            buttonFollow.visibility = View.GONE
        }
        else {
            buttonFollow.visibility = View.VISIBLE
        }

        var followClicked = MyApplication.getFollowingList().any { it.user == user }

        if (followClicked) {
            buttonFollow.setText("Following")
        }

        buttonFollow.setOnClickListener {
            if (!followClicked) {
                buttonFollow.setText("Following")
                MyApplication.addFollowingList(SavedLists(user.toString(), title, body.toString()))
                followClicked = true
            }
            else {
                MyApplication.deleteFollowingList(user.toString())
                buttonFollow.setText("Follow")
                followClicked = false
            }
        }


        view.setOnClickListener {
            MyApplication.setTitle(textViewTitle.text.toString())
            MyApplication.setName(textViewUser.getText().toString())
            MyApplication.setContent(StringBuilder(body.toString()))
            context.startActivity(Intent(context, ViewFileActivity::class.java))
        }

        return view
    }

    override fun getCount(): Int = list.size

    override fun getItem(position: Int): Any = list[position]

    override fun getItemId(position: Int): Long = position.toLong()
}