package com.example.pensee.utils

import android.content.Context
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.pensee.app.MutablePair
import com.example.pensee.app.MutableTriple
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.util.ArrayList

fun EditText.isNotValid() : Boolean {
    return this.text.toString().isEmpty()
}

fun AppCompatActivity.toast(msg: String) {
    Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}


fun AppCompatActivity.saveUserList(userList: ArrayList<Pair<ArrayList<MutablePair>, MutableTriple>>) {
    val gson = Gson()
    val json = gson.toJson(userList)
    val sharedPreferences = getSharedPreferences("users", Context.MODE_PRIVATE)
    val editor = sharedPreferences.edit()
    editor.putString("users_array_list", json)
    editor.apply()
}

fun AppCompatActivity.getUserList() : ArrayList<Pair<ArrayList<MutablePair>, MutableTriple>> {

    val sharedPreferences = getSharedPreferences("users", Context.MODE_PRIVATE)
    val json = sharedPreferences.getString("users_array_list", "")
    if (!json.isNullOrEmpty()) {
        val gson = Gson()
        return gson.fromJson(json, object : TypeToken<ArrayList<Pair<ArrayList<MutablePair>, MutableTriple>>>() {}.type)
    }
    return ArrayList()
}
