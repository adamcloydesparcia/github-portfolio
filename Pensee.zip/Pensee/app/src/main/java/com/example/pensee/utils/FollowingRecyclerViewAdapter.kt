package com.example.pensee.utils

import android.content.Context
import android.content.Intent
import android.media.Image
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.example.pensee.FollowingFragment
import com.example.pensee.LibraryFragment
import com.example.pensee.R
import com.example.pensee.ViewFileActivity
import com.example.pensee.app.MyApplication
import com.example.pensee.app.SavedLists

class FollowingRecyclerViewAdapter(private val context: Context, private val list: ArrayList<SavedLists>) : RecyclerView.Adapter<FollowingRecyclerViewAdapter.ItemViewHolder>() {
    class ItemViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val user = view.findViewById<TextView>(R.id.textView_user)
        val title = view.findViewById<TextView>(R.id.textview_title)
        val body = view.findViewById<TextView>(R.id.textview_body)
        var buttonFollow = view.findViewById<Button>(R.id.follow_button)
        var like = view.findViewById<ImageView>(R.id.heart)
        var comments = view.findViewById<ImageView>(R.id.comments)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ItemViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.public_journal_list, parent, false)

        return ItemViewHolder(view)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val user = list[position].user
        val title = list[position].title
        val body = list[position].body

        holder.user.text = user
        holder.title.text = title
        if (body.length >= 80)
            holder.body.text = body.substring(0, 80) + "..."
        else holder.body.text = body
        holder.buttonFollow.text = "Unfollow"
        holder.buttonFollow.setOnClickListener {
            MyApplication.deleteFollowingList(user)
            (context as AppCompatActivity).toast("Unfollowed " + user)
            (context as AppCompatActivity).supportFragmentManager.beginTransaction().replace(R.id.public_fragment, FollowingFragment()).commit()
        }

        var likeClicked = MyApplication.getSavedLists().any { it.title == title}
        if (likeClicked) {
            holder.like.setImageResource(R.drawable.heart_clicked)
        }
        holder.like.setOnClickListener {
            if (!likeClicked) {
                holder.like.setImageResource(R.drawable.heart_clicked)
                likeClicked = true
            }
            else {
                holder.like.setImageResource(R.drawable.heart)
                likeClicked = false
            }
        }

        holder.itemView.setOnClickListener {
            MyApplication.setTitle(title)
            MyApplication.setName(user)
            MyApplication.setContent(StringBuilder(body))
            context.startActivity(Intent(context, ViewFileActivity::class.java))
        }
    }

    override fun getItemCount(): Int = list.size
}