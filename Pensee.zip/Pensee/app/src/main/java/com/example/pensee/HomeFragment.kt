package com.example.pensee

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.pensee.app.MutablePair
import com.example.pensee.app.MyApplication
import com.example.pensee.utils.PublicCustomListAdapter
import java.lang.StringBuilder

class HomeFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        (context as AppCompatActivity).supportFragmentManager.beginTransaction().add(R.id.public_fragment, ForYouFragment()).commit()

        val buttonAdd = view.findViewById<ImageView>(R.id.add)
        buttonAdd.setOnClickListener {
            startActivity(Intent(requireContext(), CreateFileActivity::class.java))
        }

        val emptyPage = view.findViewById<ImageView>(R.id.empty_list)
        if (MyApplication.getPublicList().isEmpty()) {
            emptyPage.setImageResource(R.drawable.empty)
        }

        val buttonNotif = view.findViewById<ImageView>(R.id.notif)
        buttonNotif.setOnClickListener {
            startActivity(Intent(requireContext(), NotificationsActivity::class.java))
        }

    }

}