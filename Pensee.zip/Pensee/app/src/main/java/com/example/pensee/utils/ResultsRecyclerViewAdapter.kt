package com.example.pensee.utils

import android.content.Context
import android.content.Intent
import android.media.Image
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.example.pensee.FollowingFragment
import com.example.pensee.LibraryFragment
import com.example.pensee.R
import com.example.pensee.ViewFileActivity
import com.example.pensee.app.MutablePair
import com.example.pensee.app.MyApplication
import com.example.pensee.app.SavedLists
import java.time.LocalDate
import java.time.LocalDate.now
import kotlin.math.absoluteValue

class ResultsRecyclerViewAdapter(private val context: Context, private val list: ArrayList<Triple<String, String?, MutablePair>>) : RecyclerView.Adapter<ResultsRecyclerViewAdapter.ItemViewHolder>() {
    class ItemViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val textViewDate = view.findViewById<TextView>(R.id.date_Created)
        val textViewUser = view.findViewById<TextView>(R.id.textView_user)
        val textViewTitle = view.findViewById<TextView>(R.id.textview_title)
        val textViewBody = view.findViewById<TextView>(R.id.textview_body)
        val imageViewLike = view.findViewById<ImageView>(R.id.heart)
        val buttonFollow = view.findViewById<Button>(R.id.follow_button)

    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ItemViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.public_journal_list, parent, false)
        return ItemViewHolder(view)
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val date = list[position].first
        val user = list[position].second
        val title = list[position].third.title
        val body = list[position].third.body

        holder.textViewDate.text = now().until(LocalDate.parse(date)).days.absoluteValue.toString() + "d"
        holder.textViewUser.text = user
        holder.textViewTitle.text = title
        if (body.length >= 80)
            holder.textViewBody.text = body.substring(0, 80) + "..."
        else holder.textViewBody.text = body

        var likeClicked = MyApplication.getSavedLists().any { it.title == title }

        if (likeClicked) {
            holder.imageViewLike.setImageResource(R.drawable.heart_clicked)
        }

        holder.imageViewLike.setOnClickListener {
            if (!likeClicked) {
                holder.imageViewLike.setImageResource(R.drawable.heart_clicked)
                MyApplication.addLikedList(SavedLists(user.toString(), title, body.toString()))
                likeClicked = true
            } else {
                MyApplication.deleteLikedList(title)
                holder.imageViewLike.setImageResource(R.drawable.heart)
                likeClicked = false
            }
        }


        if (MyApplication.name() == user.toString()) {
            holder.buttonFollow.visibility = View.GONE
        } else {
            holder.buttonFollow.visibility = View.VISIBLE
        }

        var followClicked = MyApplication.getFollowingList().any { it.user == user }

        if (followClicked) {
            holder.buttonFollow.setText("Following")
        }

        holder.buttonFollow.setOnClickListener {
            if (!followClicked) {
                holder.buttonFollow.setText("Following")
                MyApplication.addFollowingList(SavedLists(user.toString(), title, body.toString()))
                followClicked = true
            } else {
                MyApplication.deleteFollowingList(user.toString())
                holder.buttonFollow.setText("Follow")
                followClicked = false
            }
        }


        holder.itemView.setOnClickListener {
            MyApplication.setTitle(title)
            MyApplication.setName(user.toString())
            MyApplication.setContent(StringBuilder(body))
            context.startActivity(Intent(context, ViewFileActivity::class.java))
        }

    }

    override fun getItemCount(): Int = list.size

}