package com.example.pensee

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.pensee.app.MyApplication
import com.example.pensee.utils.isNotValid
import com.example.pensee.utils.saveUserList
import com.example.pensee.utils.toast
import kotlin.text.StringBuilder

class EditFileActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_file)


        val buttonBack = findViewById<ImageView>(R.id.back_button)

        buttonBack.setOnClickListener {
            finish()
        }

        val textTitle = findViewById<EditText>(R.id.title_text)
        val textBody = findViewById<EditText>(R.id.body_text)

        textTitle.setText(MyApplication.getFile()?.title)
        textBody.setText(MyApplication.getFile()?.body)

        val buttonSave = findViewById<TextView>(R.id.save_button)
        buttonSave.setOnClickListener {
            if (textTitle.isNotValid() || textBody.isNotValid()) {
                toast("File should not be empty")
                return@setOnClickListener
            }

            MyApplication.updateFile(textTitle.text.toString(), StringBuilder(textBody.text.toString()))
            startActivity(Intent(this, MainActivity::class.java).putExtra("fragment", "profile"))
            finish()
        }
    }
}