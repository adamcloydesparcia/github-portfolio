package com.example.pensee

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.findViewTreeLifecycleOwner
import com.example.pensee.app.MyApplication
import com.example.pensee.utils.CustomListAdapter

class ProfileFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_profile, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val buttonShared = view.findViewById<TextView>(R.id.public_title)
        val buttonRecent = view.findViewById<TextView>(R.id.recent_title)
        val lineRecent = view.findViewById<View>(R.id.recent_line)
        val lineShared = view.findViewById<View>(R.id.public_line)
        (context as AppCompatActivity).supportFragmentManager.beginTransaction().add(R.id.list_fragment, RecentFragment()).commit()
        lineShared.visibility = View.GONE

        buttonShared.setOnClickListener {
            (context as AppCompatActivity).supportFragmentManager.beginTransaction().replace(R.id.list_fragment, SharedFragment()).commit()
            lineRecent.visibility = View.GONE
            lineShared.visibility = View.VISIBLE
        }

        buttonRecent.setOnClickListener {
            (context as AppCompatActivity).supportFragmentManager.beginTransaction().replace(R.id.list_fragment, RecentFragment()).commit()
            lineRecent.visibility = View.VISIBLE
            lineShared.visibility = View.GONE
        }

        val profileName = view.findViewById<TextView>(R.id.profile_name)
        val userEmail = view.findViewById<TextView>(R.id.user_email)

        profileName.text = MyApplication.name()
        userEmail.text = MyApplication.getEmail()

        val buttonSettings = view.findViewById<ImageView>(R.id.settings_button)
        buttonSettings.setOnClickListener {
            startActivity(Intent(requireContext(), SettingsActivity::class.java))
        }


        val buttonEditProfile = view.findViewById<ImageView>(R.id.editprofile_button)
        buttonEditProfile.setOnClickListener {
            startActivity(Intent(requireContext(), EditProfileActivity::class.java))
        }


        val followingCount = view.findViewById<TextView>(R.id.following_count)
        followingCount.setText(MyApplication.getFollowingList().size.toString())

    }

}