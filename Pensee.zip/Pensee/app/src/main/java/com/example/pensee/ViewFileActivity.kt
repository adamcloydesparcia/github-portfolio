package com.example.pensee

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.example.pensee.app.MutablePair
import com.example.pensee.app.MyApplication
import com.example.pensee.utils.getUserList
import com.example.pensee.utils.toast

class ViewFileActivity : AppCompatActivity() {

    private lateinit var filePair : MutablePair

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_file)

        val buttonBack = findViewById<ImageView>(R.id.back_button)
        val editFileButton = findViewById<TextView>(R.id.edit_button)
        val author = findViewById<TextView>(R.id.author)


        val fileName = findViewById<TextView>(R.id.file_title)
        val fileBody = findViewById<TextView>(R.id.file_body)

        if (intent?.getStringExtra("private_file") == "private_file") {
            onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    startActivity(Intent(this@ViewFileActivity, MainActivity::class.java).putExtra("fragment", "profile"))
                    finish()
                }
            })
            editFileButton.setOnClickListener {
                startActivity(Intent(this, EditFileActivity::class.java))
            }
            buttonBack.setOnClickListener {
                finish()
            }
            author.text = ""

            filePair = MyApplication.getFile()!!

            fileName.text = filePair.title
            fileBody.text = filePair.body.toString()

        }
        else {
            onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    finish()
                }
            })
            editFileButton.text = ""

            buttonBack.setOnClickListener {
                finish()
            }

            author.text = MyApplication.getName()
            fileName.text = MyApplication.getTitle()
            fileBody.text = MyApplication.getContent()
        }


    }
}