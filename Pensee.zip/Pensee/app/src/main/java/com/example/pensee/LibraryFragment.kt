package com.example.pensee

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.pensee.app.MyApplication
import com.example.pensee.app.SavedLists
import com.example.pensee.utils.SavedRecyclerViewAdapter
import com.example.pensee.utils.toast

class LibraryFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_library, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val emptyPage = view.findViewById<TextView>(R.id.empty_list)

        val list = MyApplication.getSavedLists()
        if (list.isNotEmpty()) {
            emptyPage.visibility = View.GONE
        }
        else emptyPage.visibility = View.VISIBLE

        val recyclerView = view.findViewById<RecyclerView>(R.id.recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = SavedRecyclerViewAdapter(requireContext(), list)

    }

}