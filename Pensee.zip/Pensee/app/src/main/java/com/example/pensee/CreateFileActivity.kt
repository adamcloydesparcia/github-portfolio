package com.example.pensee

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.example.pensee.app.MyApplication
import com.example.pensee.utils.isNotValid
import com.example.pensee.utils.toast

class CreateFileActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_file)

        val textTitle = findViewById<EditText>(R.id.title_text)
        val textBody = findViewById<EditText>(R.id.body_text)

        val buttonBack = findViewById<ImageView>(R.id.back_button)
        buttonBack.setOnClickListener {
            finish()
        }

        val buttonSave = findViewById<ImageView>(R.id.check)
        buttonSave.setOnClickListener {
            if (textTitle.isNotValid() || textBody.isNotValid()) {
                toast("Text fields should not be empty!")
                return@setOnClickListener
            }

            if (MyApplication.fileExists(textTitle.text.toString()) == true) {
                toast("File title already exist!")
                return@setOnClickListener
                
            }

            MyApplication.setTitle(textTitle.text.toString())
            MyApplication.addFile(textBody.text.toString())
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}