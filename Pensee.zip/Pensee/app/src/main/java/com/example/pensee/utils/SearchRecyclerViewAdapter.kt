package com.example.pensee.utils

import android.content.Context
import android.media.Image
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.example.pensee.FollowingFragment
import com.example.pensee.LibraryFragment
import com.example.pensee.R
import com.example.pensee.app.MyApplication
import com.example.pensee.app.SavedLists

class SearchRecyclerViewAdapter(private val context: Context, private val list: ArrayList<String>) : RecyclerView.Adapter<SearchRecyclerViewAdapter.ItemViewHolder>() {
    class ItemViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val history = view.findViewById<TextView>(R.id.history)
        val delete = view.findViewById<ImageView>(R.id.delete)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ItemViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.search_history_list, parent, false)
        return ItemViewHolder(view)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {

    }

    override fun getItemCount(): Int = list.size
}