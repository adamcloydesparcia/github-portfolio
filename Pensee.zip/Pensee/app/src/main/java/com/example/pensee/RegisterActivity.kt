package com.example.pensee

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.pensee.app.MyApplication
import com.example.pensee.utils.isNotValid
import com.example.pensee.utils.saveUserList
import com.example.pensee.utils.toast

class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val username = findViewById<EditText>(R.id.username_input)
        val email = findViewById<EditText>(R.id.email_input)
        val password = findViewById<EditText>(R.id.enter_password_input)
        val passwordConfirmed = findViewById<EditText>(R.id.confirm_password_input)

        val buttonRegister = findViewById<Button>(R.id.button_register)
        val buttonLogin = findViewById<TextView>(R.id.button_login)

        buttonLogin.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        buttonRegister.setOnClickListener {
            if (username.isNotValid() ||
                email.isNotValid() ||
                password.isNotValid()
                ) {
                toast("Please fill up the form completely!")
                return@setOnClickListener
            }

            if (password.text.toString() != passwordConfirmed.text.toString()) {
                toast("Passwords doesn't match!")
                return@setOnClickListener
            }

            if (MyApplication.emailExists(email.text.toString())) {
                toast("A user is already using that email")
                return@setOnClickListener
            }

            MyApplication.addUser(username.text.toString(), email.text.toString(), password.text.toString())
            val builder = AlertDialog.Builder(this)
            builder.setMessage("Account created successfully!")
            builder.setPositiveButton("continue") { _, _ ->
                saveUserList(MyApplication.getUserList())
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
            }
            builder.show()

        }
    }
}